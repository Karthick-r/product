<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\User;
use Illuminate\Support\Facades\View;
use DB;
use Validator;



class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index()
    {
        $admins=User::where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        return view('admin/index',['admins'=>$admins]);  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/create'); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       

 $validator = Validator::make($request->all(), 
      [     'name' => 'required|string|max:255',
            'phone' => 'required|unique:users,phone',
            'email' => 'required|string|email|max:255|unique:users',           
            'password' => 'required|string|min:6|confirmed',            
            'admin'=>'required',
      ],
      [
      'name.required'=>"Enter your Name",
      'admin.required'=>"Select Admin Or Superadmin",   
      'phone' =>"Phone Number Already taken",
      'email' => "Email Already taken",        
      
      ]);

        if ($validator->fails())
         {

            $notification = array(
            'message' => 'your data error.', 
            'alert-type' => 'warning' );      
             return redirect()->back()->withErrors($validator)->with($notification)->withInput();
         }

 else
         {
      
            $admin = new User;
            $admin->name=$request->input('name');   
            $admin->email=$request->input('email');                   
            $admin->password=bcrypt($request->input('password'));  
            $admin->phone=$request->input('phone');   
            $admin->role_id=$request->input('admin');         
            $admin->status=1;
            $admin->deleted_on_off=1;  
            $admin->created_at= new \DateTime();
            $admin->save();
             $notification = array(
            'message' => 'your data inserted.', 
            'alert-type' => 'success' ); 
            return Redirect::to('admin')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $admin = User::find($id);
        if($admin->status==0)
        {
        $admin->status=1;

        $notification = array(
            'message' => 'admin is Unblocked', 
            'alert-type' => 'success');
              }
              
              else
                { 
                     $admin->status=0;
                     $notification = array(
            'message' => 'Admin is blocked', 
            'alert-type' => 'error');
              }
              

        $admin->updated_at=new \DateTime();
        $admin->save();

        return Redirect::to('admin')->with($notification);//
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $admin = User ::find($id);
      return View::make('admin.edit')->with('admin',$admin) ;
    }


 public function password($id)
    {
      $admin = User ::find($id);
      return View::make('admin.admin.password')->with('admin',$admin) ; ////
    }

    public function password_update(Request $request, $id)
    {
              
 $this->validate($request,
       
        [
            'password' => 'required|string|min:6|confirmed',

        ]); 
            $admin = User ::find($id);           
            $admin->password=bcrypt($request->input('password'));  
            $admin->updated_at= new \DateTime();
            $admin->save();
            $notification = array(
            'message' => 'Your Password changed', 
            'alert-type' => 'success');
            return Redirect::to('admin')->with($notification);  

    }





    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
              
 $this->validate($request,
       
        [
            'name' => 'required|string|max:255',
            'admin'=>'required',
            'phone' => 'unique:users,phone,'.$id.',id',
           
            'email' => 'unique:users,email,'.$id.',id'
        ],
        [
            'name.required'=>"Enter your Name",
             'admin.required'=>"Select Admin Or Superadmin", 
             'email.required'=>"Email Alredy Taken",
             'phone.required'=>"Phone Number Alredy Taken",          

            ]); 

            $admin = User ::find($id);           
            $admin->name=$request->input('name');
            $admin->phone=$request->input('phone');
            $admin->email=$request->input('email');
            $admin->role_id=$request->input('admin');
            
            $admin->updated_at= new \DateTime();
            $admin->save();
            $notification = array(
            'message' => 'Your Employee details is updated', 
            'alert-type' => 'success');
            return Redirect::to('admin')->with($notification);


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
            $admin = User ::find($id);
            $admin->deleted_on_off= 0;
            $admin->deleted_at= new \DateTime();
            $admin->save();

            

                $notification = array(
            'message' => 'Employee is Deleted', 
            'alert-type' => 'success');
            return Redirect::to('admin')->with($notification);  //
    }
}
