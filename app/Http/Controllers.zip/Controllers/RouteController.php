<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Routes;
use Illuminate\Support\Facades\View;
use DB;
use Validator;
use App\District;
use App\User;


class RouteController extends Controller
{
    public function index()
    {
        //$routes=route::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();
        $routes=Routes::where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        return view('route/index',['routes'=>$routes]);  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $districts=District::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();    
        return view('route/create',['districts'=>$districts]);  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       

 $validator = Validator::make($request->all(), 
      [    'name' => 'required|unique:routes,name',
            'district' => 'required',
          
      ],
      [
      'name.required'=>"Enter your Name",
      'district.required'=>"Select District",   
    
      ]);

        if ($validator->fails())
         {

            $notification = array(
            'message' => 'your data error.', 
            'alert-type' => 'warning' );      
             return redirect()->back()->withErrors($validator)->with($notification)->withInput();
         }

 else
         {
      
            $route = new Routes;
            $route->name=$request->input('name');   
            $route->district_id=$request->input('district');  
            
            
            $dis = District::find($route->district_id);
            $sta=$dis->zone_id;
            $route->zone_id= $sta;
            
            
 
            $zone = Zone::find($district->zone_id);
            $sta=$zone->state_id;
            $route->state_id= $sta;
 
 
            $state = State::find($zone->state_id);
            $cou=$state->country_id;
            $route->country_id= $cou;            
              
            $route->status=1;
            $route->deleted_on_off=1;  
            $route->created_at= new \DateTime();
            $route->save();
             $notification = array(
            'message' => 'your data inserted.', 
            'alert-type' => 'success' ); 
            return Redirect::to('route')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $route = Routes::find($id);
        if($route->status==0)
        {
        $route->status=1;

        $notification = array(
            'message' => 'route is Unblocked', 
            'alert-type' => 'success');
              }
              
              else
                { 
                     $route->status=0;
                     $notification = array(
            'message' => 'route is blocked', 
            'alert-type' => 'error');
              }
              

        $route->updated_at=new \DateTime();
        $route->save();

        return Redirect::to('route')->with($notification);//
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $route = Routes ::find($id);

      $districts=District::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get(); 
      return view('route.edit',['districts'=>$districts,'route'=>$route]);  
     // return View::make('route.edit')->with('route',$route) ;
    }








    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
              
        $validator = Validator::make($request->all(), 
        [   'name' => 'required|unique:routes,name,'.$id.',id',
      
              'district' => 'required',
            
        ],
        [
        'name.required'=>"Enter your Name",
        'district.required'=>"Select District",   
      
        ]);


        if ($validator->fails())
        {

           $notification = array(
           'message' => 'your data error.', 
           'alert-type' => 'warning' );      
            return redirect()->back()->withErrors($validator)->with($notification)->withInput();
        }

else
        {
     
            $route = Routes ::find($id);           
           $route->name=$request->input('name');   
           $route->district_id=$request->input('district');  
           
           $dis = District::find($route->district_id);
           $sta=$dis->zone_id;
           $route->zone_id= $sta;
           
           

           $zone = Zone::find($district->zone_id);
           $sta=$zone->state_id;
           $route->state_id= $sta;


           $state = State::find($zone->state_id);
           $cou=$state->country_id;
           $route->country_id= $cou;
         
           $route->save();
            $notification = array(
           'message' => 'Your Sate details is updated', 
           'alert-type' => 'success' ); 
           return Redirect::to('route')->with($notification);
       }

    


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
            $route = Route ::find($id);
            $route->deleted_on_off= 0;
            $route->deleted_at= new \DateTime();
            $route->save();

            

                $notification = array(
            'message' => 'route is Deleted', 
            'alert-type' => 'success');
            return Redirect::to('route')->with($notification);  //
    }


    public function allocate_index()
    {
        //$countrys=Country::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();
        $routes=Routes::where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        $admins=User::where('role_id', '5')->where('status', '1')->where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        return view('route/allocate',['routes'=>$routes,'admins'=>$admins]);  
    }


    public function allocate($id1,$id2)
    {
        //$countrys=Country::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();

        $routes = Routes ::find($id2);
        $routes->user_id=$id1; 
        $routes->updated_at=new \DateTime();
        $routes->save(); 

        $notification = array(
            'message' => 'User Allocated To State', 
            'alert-type' => 'success' ); 
            return Redirect::to('route_allocate')->with($notification);
        
    }

}

