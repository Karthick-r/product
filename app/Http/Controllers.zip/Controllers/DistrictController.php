<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Zone;
use Illuminate\Support\Facades\View;
use DB;
use Validator;
use App\District;
use App\User;

class DistrictController extends Controller
{
    public function index()
    {
        //$zones=zone::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();
        $districts=District::where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        return view('district/index',['districts'=>$districts]);  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $zones=Zone::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();    
        return view('district/create',['zones'=>$zones]);  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       

 $validator = Validator::make($request->all(), 
      [    'name' => 'required|unique:districts,name',
            'zone' => 'required',
          
      ],
      [
      'name.required'=>"Enter your Name",
      'zone.required'=>"Select zone",   
    
      ]);

        if ($validator->fails())
         {

            $notification = array(
            'message' => 'your data error.', 
            'alert-type' => 'warning' );      
             return redirect()->back()->withErrors($validator)->with($notification)->withInput();
         }

 else
         {
      
            $district = new district;
            $district->name=$request->input('name');   
            $district->zone_id=$request->input('zone');   
          
            
            $zone = Zone::find($district->zone_id);
            $sta=$zone->state_id;
            $$district->state_id= $sta;


            $state = State::find($zone->state_id);
            $cou=$state->country_id;
            $district->country_id= $cou;
              
            $district->status=1;
            $district->deleted_on_off=1;  
            $district->created_at= new \DateTime();
            $district->save();
             $notification = array(
            'message' => 'your data inserted.', 
            'alert-type' => 'success' ); 
            return Redirect::to('district')->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $district = District::find($id);
        if($district->status==0)
        {
        $district->status=1;

        $notification = array(
            'message' => 'district is Unblocked', 
            'alert-type' => 'success');
              }
              
              else
                { 
                     $district->status=0;
                     $notification = array(
            'message' => 'district is blocked', 
            'alert-type' => 'error');
              }
              

        $district->updated_at=new \DateTime();
        $district->save();

        return Redirect::to('district')->with($notification);//
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $district = District ::find($id);

      $zones=zone::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get(); 
      return view('district.edit',['zones'=>$zones,'district'=>$district]);  
     // return View::make('district.edit')->with('district',$district) ;
    }








    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
              
        $validator = Validator::make($request->all(), 
        [
        'name' => 'required|unique:districts,name, '.$id.',id',
        'zone' => 'required',
            
        ],
        [
        'name.required'=>"Enter your Name",
        'zone.required'=>"Select zone",   
      
        ]);


        if ($validator->fails())
        {

           $notification = array(
           'message' => 'your data error.', 
           'alert-type' => 'warning' );      
            return redirect()->back()->withErrors($validator)->with($notification)->withInput();
        }

else
        {
     
            $district = district ::find($id);           
           $district->name=$request->input('name');   
           $district->zone_id=$request->input('zone');   
           
           
           $zone = Zone::find($district->zone_id);
           $sta=$zone->state_id;
           $$district->state_id= $sta;


           $state = State::find($zone->state_id);
           $cou=$state->country_id;
           $district->country_id= $cou;
         
           $district->save();
            $notification = array(
           'message' => 'Your Sate details is updated', 
           'alert-type' => 'success' ); 
           return Redirect::to('district')->with($notification);
       }

    


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
            $district = district ::find($id);
            $district->deleted_on_off= 0;
            $district->deleted_at= new \DateTime();
            $district->save();

            

                $notification = array(
            'message' => 'district is Deleted', 
            'alert-type' => 'success');
            return Redirect::to('district')->with($notification);  //
    }

    public function allocate_index()
    {
        //$countrys=Country::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();
        $districts=district::where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        $admins=User::where('role_id', '4')->where('status', '1')->where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        $zones=Zone::where('status', '1')->where('deleted_on_off', '1')->orderBy('created_at', 'DESC')->get();
        return view('district/allocate',['districts'=>$districts,'admins'=>$admins,'zones'=>$zones]); 
        
        
    }



    public function allocate($id1,$id2)
    {
        //$countrys=Country::orderBy('created_at', 'DESC')->where('deleted_on_off', '1')->where('status', '1')->get();

        $district = district ::find($id2);
        $district->user_id=$id1; 
        $district->updated_at=new \DateTime();
        $district->save(); 

        $notification = array(
            'message' => 'User Allocated To State', 
            'alert-type' => 'success' ); 
            return Redirect::to('district_allocate')->with($notification);
        
    }

}

